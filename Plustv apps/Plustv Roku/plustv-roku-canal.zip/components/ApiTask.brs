sub init()
  m.top.functionName = "go"
end sub

sub go()
  req = CreateObject("roUrlTransfer")
  req.SetCertificatesFile("common:/certs/ca-bundle.crt")
  req.InitClientCertificates()
  req.SetUrl(m.top.url)
  req.AddHeader("User-Agent", "VLC/3.0.20 LibVLC/3.0.20")
  port = CreateObject("roMessagePort")
  req.SetMessagePort(port)
  if m.top.body <> "" then
    req.AddHeader("Content-Type", "application/json")
    ok = req.AsyncPostFromString(m.top.body)
  else
    ok = req.AsyncGetToString()
  end if
  if not ok then
    m.top.status = -1
    return
  end if
  tmo = m.top.timeout
  if tmo <= 0 then tmo = 30000
  msg = wait(tmo, port)
  if type(msg) = "roUrlEvent" then
    m.top.text = msg.GetString()
    code = msg.GetResponseCode()
    if code <= 0 then code = -1
    m.top.status = code
  else
    req.AsyncCancel()
    m.top.status = -1
  end if
end sub
