' PlusTV Player - canal Roku.
' Login (usuário/senha e, opcionalmente, o código do player do seu revendedor) -> listas do servidor IPTV -> reprodução.

' Endereço padrão do painel (usado se o endereço de descoberta e o último endereço salvo falharem).
function DEFAULT_PANEL() as string
  return "https://konnex.business"
end function

' Endereço de descoberta: um arquivo JSON {"panel":"https://..."} num lugar que você nunca troca (domínio curto, Cloudflare Pages, GitHub).
' Se você mudar o domínio do painel, basta editar esse arquivo - sem enviar novo pacote para a loja. Deixe "" para desativar.
function DISCOVERY_URL() as string
  return "https://raw.githubusercontent.com/plustvuhd/plustv-config/main/plustv.json"
end function

function PANEL_URL() as string
  if m.panel <> invalid and m.panel <> "" then return m.panel
  return DEFAULT_PANEL()
end function

sub init()
  m.bg = m.top.findNode("bg")
  m.topBar = m.top.findNode("topBar")
  m.logo = m.top.findNode("logo")
  m.title = m.top.findNode("title")
  m.loginList = m.top.findNode("loginList")
  m.menu = m.top.findNode("menu")
  m.setList = m.top.findNode("setList")
  m.cats = m.top.findNode("cats")
  m.grid = m.top.findNode("grid")
  m.eps = m.top.findNode("eps")
  m.info = m.top.findNode("info")
  m.status = m.top.findNode("status")
  m.video = m.top.findNode("video")
  m.ovShade = m.top.findNode("ovShade")
  m.ovTitle = m.top.findNode("ovTitle")
  m.pbBg = m.top.findNode("pbBg")
  m.pbFill = m.top.findNode("pbFill")
  m.pbTime = m.top.findNode("pbTime")
  m.pbHint = m.top.findNode("pbHint")
  m.actBg = m.top.findNode("actBg")
  m.actLabel = m.top.findNode("actLabel")
  m.epgNow = m.top.findNode("epgNow")
  m.epgNext = m.top.findNode("epgNext")
  m.sample = m.top.findNode("sample")
  m.fontLvl = 0
  fl = m.reg.Read("fontlvl")
  if fl = "1" then m.fontLvl = 1
  if fl = "2" then m.fontLvl = 2
  m.ovTimer = m.top.findNode("ovTimer")
  m.ovTimer.observeField("fire", "onOvHide")
  m.video.observeField("position", "onPos")
  m.act = ""
  m.skipDone = false
  m.paused = false
  m.rnMsg = m.top.findNode("rnMsg")
  m.qrBg = m.top.findNode("qrBg")
  m.qr = m.top.findNode("qr")
  m.rnList = m.top.findNode("rnList")
  m.poll = m.top.findNode("poll")
  m.prgBg = m.top.findNode("prgBg")
  m.prgFill = m.top.findNode("prgFill")
  m.prgTitle = m.top.findNode("prgTitle")
  m.prgText = m.top.findNode("prgText")

  m.reg = CreateObject("roRegistrySection", "plustv")
  m.owner = m.reg.Read("owner")
  m.user = m.reg.Read("user")
  m.pass = m.reg.Read("pass")
  m.fmtPref = m.reg.Read("fmt")
  if m.fmtPref <> "hls" and m.fmtPref <> "ts" then m.fmtPref = "auto"
  m.learned = m.reg.Read("learned")
  m.autoNext = m.reg.Read("autonext") <> "0"
  m.pin = m.reg.Read("pin")
  if m.pin = "" then m.pin = "000"
  m.unlocked = false
  m.hideEdit = false
  m.hideKind = "live"
  m.hide = {live: [], movie: [], series: []}
  hj = m.reg.Read("hide")
  if hj <> "" then
    pj = ParseJson(hj)
    if pj <> invalid and type(pj) = "roAssociativeArray" then
      for each kk in ["live", "movie", "series"]
        if pj[kk] <> invalid then m.hide[kk] = pj[kk]
      end for
    end if
  end if
  m.catCache = {}
  m.cands = []
  m.candIdx = 0
  m.sess = invalid
  m.kind = "live"
  m.state = "login"
  m.items = []
  m.episodes = []
  m.epIndex = 0
  m.adultRe = CreateObject("roRegex", "adult|xxx|\+\s?18|18\s?\+|porn|sexo|sexy|putaria|playboy|brazzers|er.tic", "i")

  m.loginList.observeField("itemSelected", "onLoginSelect")
  m.menu.observeField("itemSelected", "onMenuSelect")
  m.setList.observeField("itemSelected", "onSetSelect")
  m.rnList.observeField("itemSelected", "onRnSelect")
  m.poll.observeField("fire", "onPoll")
  m.warned = false
  m.canPay = false
  m.cats.observeField("itemSelected", "onCatSelect")
  m.grid.observeField("itemSelected", "onItemSelect")
  m.eps.observeField("itemSelected", "onEpSelect")
  m.video.observeField("state", "onVideoState")

  applyFonts()
  m.cfg = { notice: "", maintenance: false, maintenanceMsg: "", introFrom: 3, introTo: 150, introEnd: 90, seek: 10, seekBig: 30, nextSecs: 10 }
  setStatus("Conectando...")
  m.panel = DEFAULT_PANEL()
  m.panelList = []
  m.panelIdx = 0
  m.lastPanel = m.reg.Read("panel")
  du = DISCOVERY_URL()
  if du <> "" and Instr(1, du, "SEU-DOMINIO") = 0 then
    t = CreateObject("roSGNode", "ApiTask")
    t.url = du
    t.body = ""
    t.timeout = 6000
    t.observeField("status", "onDiscovery")
    m.dtask = t
    t.control = "RUN"
  else
    buildPanelList("")
  end if
end sub

sub onDiscovery()
  found = ""
  if m.dtask.status = 200 and m.dtask.text <> "" then
    j = ParseJson(m.dtask.text)
    if j <> invalid and type(j) = "roAssociativeArray" and j.panel <> invalid then
      p = S(j.panel).Trim()
      while Len(p) > 0 and Right(p, 1) = "/"
        p = Left(p, Len(p) - 1)
      end while
      if Left(p, 8) = "https://" then found = p
    end if
  end if
  buildPanelList(found)
end sub

' Ordem de tentativa: descoberto > último que funcionou > padrão do pacote
sub buildPanelList(found as string)
  lst = []
  for each c in [found, m.lastPanel, DEFAULT_PANEL()]
    if c <> invalid and c <> "" then
      dup = false
      for each x in lst
        if x = c then dup = true
      end for
      if not dup then lst.Push(c)
    end if
  end for
  m.panelList = lst
  m.panelIdx = 0
  tryPanel()
end sub

sub tryPanel()
  m.panel = m.panelList[m.panelIdx]
  t = CreateObject("roSGNode", "ApiTask")
  t.url = m.panel + "/api/public/roku/config"
  t.body = ""
  t.timeout = 8000
  t.observeField("status", "onConfig")
  m.task = t
  t.control = "RUN"
end sub

' Ajustes remotos (mudam no painel sem precisar enviar novo pacote para a loja)
sub onConfig()
  if m.task.status <> 200 and m.panelIdx + 1 < m.panelList.Count() then
    m.panelIdx = m.panelIdx + 1
    tryPanel()
    return
  end if
  if m.task.status = 200 and m.lastPanel <> m.panel then
    m.reg.Write("panel", m.panel)
    m.reg.Flush()
    m.lastPanel = m.panel
  end if
  j = invalid
  if m.task.status = 200 and m.task.text <> "" then j = ParseJson(m.task.text)
  if j <> invalid and type(j) = "roAssociativeArray" then
    for each k in ["introFrom", "introTo", "introEnd", "seek", "seekBig", "nextSecs"]
      if j[k] <> invalid then m.cfg[k] = j[k]
    end for
    if j.notice <> invalid then m.cfg.notice = S(j.notice)
    if j.maintenanceMsg <> invalid then m.cfg.maintenanceMsg = S(j.maintenanceMsg)
    if j.maintenance = true then m.cfg.maintenance = true
  end if
  if m.cfg.maintenance then
    hideAll()
    m.state = "maint"
    m.logo.uri = "pkg:/images/icon_hd.png"
    m.logo.visible = true
    m.title.text = "Em manutenção"
    m.title.visible = true
    m.info.text = "Pressione Voltar para sair"
    setStatus(m.cfg.maintenanceMsg)
    return
  end if
  if m.user <> "" and m.pass <> "" then
    doLogin()
  else
    showLogin("")
  end if
end sub

' ---------- utilidades ----------
function S(v as dynamic) as string
  if v = invalid then return ""
  t = type(v)
  if t = "roString" or t = "String" then return v
  if t = "roInt" or t = "Integer" or t = "roInteger" or t = "roFloat" or t = "Float" or t = "Double" or t = "roDouble" or t = "LongInteger" then return v.ToStr()
  return ""
end function

function enc(v as string) as string
  u = CreateObject("roUrlTransfer")
  return u.Escape(v)
end function

function maskStr(v as string) as string
  r = ""
  for i = 1 to Len(v)
    r = r + "*"
  end for
  return r
end function

sub callApi(url as string, body as string, handler as string)
  t = CreateObject("roSGNode", "ApiTask")
  t.url = url
  t.body = body
  t.observeField("status", handler)
  m.task = t
  t.control = "RUN"
end sub

function apiBase() as string
  return m.sess.base + "/player_api.php?username=" + enc(m.sess.user) + "&password=" + enc(m.sess.pass)
end function

sub hideAll()
  m.loginList.visible = false
  m.menu.visible = false
  m.setList.visible = false
  m.sample.visible = false
  m.rnMsg.visible = false
  m.qrBg.visible = false
  m.qr.visible = false
  m.rnList.visible = false
  m.poll.control = "stop"
  m.cats.visible = false
  m.grid.visible = false
  m.eps.visible = false
  m.title.visible = false
  m.logo.visible = false
  m.status.text = ""
  m.prgBg.visible = false
  m.prgFill.visible = false
  m.prgTitle.visible = false
  m.prgText.visible = false
end sub

sub setStatus(msg as string)
  m.status.text = msg
end sub

' ---------- login ----------
sub showLogin(msg as string)
  hideAll()
  m.state = "login"
  m.logo.uri = "pkg:/images/icon_hd.png"
  m.logo.visible = true
  buildLoginList()
  m.loginList.visible = true
  m.loginList.setFocus(true)
  m.info.text = "Use o controle para preencher e escolha ENTRAR"
  if msg = "" and m.cfg.notice <> "" then msg = m.cfg.notice
  setStatus(msg)
end sub

sub buildLoginList()
  c = CreateObject("roSGNode", "ContentNode")
  rows = ["Código do player (opcional): " + m.owner, "Usuário: " + m.user, "Senha: " + maskStr(m.pass), "ENTRAR"]
  for each r in rows
    n = c.CreateChild("ContentNode")
    n.title = r
  end for
  m.loginList.content = c
end sub

sub onLoginSelect()
  i = m.loginList.itemSelected
  if i = 0 then
    askText("Código do player (deixe vazio se não tiver)", m.owner, false, "owner")
  else if i = 1 then
    askText("Usuário", m.user, false, "user")
  else if i = 2 then
    askText("Senha", m.pass, true, "pass")
  else if i = 3 then
    if m.user = "" or m.pass = "" then
      setStatus("Informe usuário e senha.")
    else
      doLogin()
    end if
  end if
end sub

sub askText(title as string, current as string, secure as boolean, field as string)
  d = CreateObject("roSGNode", "StandardKeyboardDialog")
  d.title = title
  d.text = current
  d.buttons = ["OK", "Cancelar"]
  d.observeFieldScoped("buttonSelected", "onKbDone")
  m.kbField = field
  m.kb = d
  m.top.dialog = d
  if secure then d.textEditBox.secureMode = true
end sub

sub onKbDone()
  idx = m.kb.buttonSelected
  value = m.kb.text
  m.kb.close = true
  m.kb = invalid
  if idx = 0 then
    value = value.Trim()
    if m.kbField = "owner" then m.owner = value
    if m.kbField = "user" then m.user = value
    if m.kbField = "pass" then m.pass = value
    if Left(m.kbField, 3) = "pin" then
      onPinInput(m.kbField, value)
      return
    end if
    buildLoginList()
  end if
  if m.kbField = "pincat" then
    m.cats.setFocus(true)
    return
  end if
  if Left(m.kbField, 3) = "pin" then
    m.setList.setFocus(true)
    return
  end if
  m.loginList.setFocus(true)
end sub

sub doLogin()
  hideAll()
  setStatus("Entrando...")
  body = FormatJson({ owner: m.owner, usuario: m.user, senha: m.pass })
  callApi(PANEL_URL() + "/api/public/roku/login", body, "onLoginDone")
end sub

sub onLoginDone()
  txt = m.task.text
  j = invalid
  if txt <> "" then j = ParseJson(txt)
  if j <> invalid and j.expired = true then
    m.canPay = (j.canPay = true)
    m.expiredLogin = true
    showRenewPrompt("Seu acesso venceu.")
    return
  end if
  if m.task.status <> 200 or j = invalid or j.ok <> true then
    msg = "Não foi possível entrar."
    if j <> invalid and j.error <> invalid then msg = S(j.error)
    if m.task.status = -1 then msg = "Sem conexão com o servidor. Tente de novo."
    showLogin(msg)
    return
  end if
  proto = "http"
  if j.https = true then proto = "https"
  m.sess = {
    base: proto + "://" + S(j.host)
    user: S(j.user)
    pass: S(j.pass)
    title: S(j.title)
    logo: S(j.logo)
    color1: S(j.color1)
    due: S(j.due)
    dueDays: j.dueDays
    canPay: (j.canPay = true)
    name: S(j.name)
  }
  m.reg.Write("owner", m.owner)
  m.reg.Write("user", m.user)
  m.reg.Write("pass", m.pass)
  m.expiredLogin = false
  m.canPay = (j.canPay = true)
  m.reg.Flush()
  startPreload()
end sub

' ---------- carregando conteúdos (Canais, Filmes, Séries) antes de abrir o menu ----------
sub startPreload()
  hideAll()
  m.state = "preload"
  m.catCache = {}
  m.preStep = 0
  m.preActions = ["get_live_categories", "get_vod_categories", "get_series_categories"]
  m.preNames = ["Canais", "Filmes", "Séries"]
  m.prgTitle.visible = true
  m.prgBg.visible = true
  m.prgFill.visible = true
  m.prgText.visible = true
  updatePreload()
  callApi(apiBase() + "&action=" + m.preActions[0], "", "onPreload")
end sub

sub updatePreload()
  m.prgFill.width = Int(600 * m.preStep / 3 + 600 / 6)
  if m.preStep >= 3 then m.prgFill.width = 600
  txt = ""
  for i = 0 to 2
    mark = "  "
    if m.preStep > i then
      mark = "OK "
    else if m.preStep = i then
      mark = "... "
    end if
    txt = txt + mark + m.preNames[i] + "      "
  end for
  m.prgText.text = txt
end sub

sub onPreload()
  arr = invalid
  if m.task.status = 200 then arr = ParseJson(m.task.text)
  if arr <> invalid and type(arr) = "roArray" then m.catCache[m.preActions[m.preStep]] = arr
  m.preStep = m.preStep + 1
  updatePreload()
  if m.preStep >= 3 then
    showMenu()
    checkDueWarning()
  else
    callApi(apiBase() + "&action=" + m.preActions[m.preStep], "", "onPreload")
  end if
end sub

' ---------- menu ----------
sub showMenu()
  hideAll()
  m.state = "menu"
  if m.sess.logo <> "" then m.logo.uri = m.sess.logo else m.logo.uri = "pkg:/images/icon_hd.png"
  m.logo.visible = true
  if Len(m.sess.color1) = 7 then m.topBar.color = "0x" + Mid(m.sess.color1, 2, 6) + "FF"
  c = CreateObject("roSGNode", "ContentNode")
  for each r in ["Canais ao vivo", "Filmes", "Séries", "Configurações", "Sair desta conta"]
    n = c.CreateChild("ContentNode")
    n.title = r
  end for
  m.menu.content = c
  m.menu.visible = true
  m.menu.setFocus(true)
  if m.sess.due <> "" then m.info.text = "Vencimento " + m.sess.due else m.info.text = ""
  if m.cfg.notice <> "" then setStatus(m.cfg.notice)
end sub

function fmtLabel() as string
  if m.fmtPref = "hls" then return "HLS (m3u8)"
  if m.fmtPref = "ts" then return "TS"
  return "Automático"
end function

sub onMenuSelect()
  i = m.menu.itemSelected
  if i = 3 then
    showSettings()
    return
  end if
  if i = 4 then
    m.reg.Delete("pass")
    m.reg.Flush()
    m.pass = ""
    m.sess = invalid
    showLogin("")
    return
  end if
  if i = 0 then
    m.kind = "live"
    action = "get_live_categories"
    m.heading = "Canais ao vivo"
  else if i = 1 then
    m.kind = "movie"
    action = "get_vod_categories"
    m.heading = "Filmes"
  else
    m.kind = "series"
    action = "get_series_categories"
    m.heading = "Séries"
  end if
  if m.catCache[action] <> invalid then
    buildCats(m.catCache[action])
    return
  end if
  setStatus("Carregando...")
  callApi(apiBase() + "&action=" + action, "", "onCats")
end sub

' ---------- categorias ----------
sub onCats()
  arr = invalid
  if m.task.status = 200 then arr = ParseJson(m.task.text)
  if arr = invalid or type(arr) <> "roArray" then
    setStatus("Não consegui carregar a lista agora.")
    return
  end if
  buildCats(arr)
end sub

sub buildCats(arr as object)
  c = CreateObject("roSGNode", "ContentNode")
  for each cat in arr
    nm = S(cat.category_name)
    if nm <> "" and not isHidden(nm) then
      n = c.CreateChild("ContentNode")
      isAd = m.adultRe.IsMatch(nm)
      if isAd then n.title = "[PIN] " + nm else n.title = nm
      n.addFields({ cid: S(cat.category_id), cname: nm, adult: isAd })
    end if
  end for
  m.cats.content = c
  showCats()
end sub

sub showCats()
  hideAll()
  m.state = "cats"
  m.title.text = m.heading
  m.title.visible = true
  m.hideEdit = false
  m.cats.unobserveField("itemSelected")
  m.cats.observeField("itemSelected", "onCatSelect")
  m.cats.visible = true
  m.cats.setFocus(true)
  m.info.text = "OK para abrir a pasta  |  Voltar para o menu"
end sub

sub onCatSelect()
  node = m.cats.content.getChild(m.cats.itemSelected)
  if node = invalid then return
  if node.adult = true then
    m.pendCid = node.cid
    m.pendName = node.cname
    askText("PIN para abrir a pasta", "", true, "pincat")
    return
  end if
  openCatById(node.cid, node.title)
end sub

sub openCatById(cid as string, nm as string)
  m.catName = nm
  if m.kind = "live" then
    act = "get_live_streams"
  else if m.kind = "movie" then
    act = "get_vod_streams"
  else
    act = "get_series"
  end if
  setStatus("Carregando " + nm + "...")
  callApi(apiBase() + "&action=" + act + "&category_id=" + enc(cid), "", "onItems")
end sub

' ---------- itens ----------
sub onItems()
  arr = invalid
  if m.task.status = 200 then arr = ParseJson(m.task.text)
  if arr = invalid or type(arr) <> "roArray" then
    setStatus("Não consegui abrir essa pasta.")
    return
  end if
  c = CreateObject("roSGNode", "ContentNode")
  count = 0
  for each it in arr
    if count >= 5000 then exit for
    n = c.CreateChild("ContentNode")
    nm = S(it.name)
    n.title = nm
    n.shortDescriptionLine1 = nm
    if m.kind = "series" then
      n.HDPosterUrl = S(it.cover)
      n.addFields({ sid: S(it.series_id), ext: "" })
    else
      n.HDPosterUrl = S(it.stream_icon)
      ext = S(it.container_extension)
      if ext = "" then ext = "mp4"
      n.addFields({ sid: S(it.stream_id), ext: ext })
    end if
    count = count + 1
  end for
  m.grid.content = c
  if count = 0 then
    setStatus("Pasta vazia.")
    return
  end if
  showItems()
end sub

sub showItems()
  hideAll()
  m.state = "items"
  m.title.text = m.heading + "  -  " + m.catName
  m.title.visible = true
  m.grid.visible = true
  m.grid.setFocus(true)
  m.info.text = "OK para assistir  |  Voltar para as pastas"
end sub

sub onItemSelect()
  node = m.grid.content.getChild(m.grid.itemSelected)
  if node = invalid then return
  if m.kind = "live" then
    lb = m.sess.base + "/live/" + enc(m.sess.user) + "/" + enc(m.sess.pass) + "/" + node.sid
    hlsC = {url: lb + ".m3u8", fmt: "hls"}
    tsC = {url: lb + ".ts", fmt: "ts"}
    first = m.fmtPref
    if first = "auto" then
      first = m.learned
      if first <> "ts" then first = "hls"
    end if
    if first = "ts" then cands = [tsC, hlsC] else cands = [hlsC, tsC]
    m.curSid = node.sid
    playList(cands, node.title)
    loadEpg(node.sid)
  else if m.kind = "movie" then
    mb = m.sess.base + "/movie/" + enc(m.sess.user) + "/" + enc(m.sess.pass) + "/" + node.sid
    cands = [{url: mb + "." + node.ext, fmt: fmtFor(node.ext)}]
    if LCase(node.ext) <> "mp4" then cands.Push({url: mb + ".mp4", fmt: "mp4"})
    playList(cands, node.title)
  else
    m.seriesName = node.title
    setStatus("Carregando episódios...")
    callApi(apiBase() + "&action=get_series_info&series_id=" + enc(node.sid), "", "onEpisodes")
  end if
end sub

function fmtFor(ext as string) as string
  e = LCase(ext)
  if e = "mkv" then return "mkv"
  if e = "ts" then return "ts"
  if e = "m3u8" then return "hls"
  return "mp4"
end function

' ---------- episódios ----------
sub onEpisodes()
  j = invalid
  if m.task.status = 200 then j = ParseJson(m.task.text)
  if j = invalid or j.episodes = invalid then
    setStatus("Não encontrei episódios.")
    return
  end if
  list = []
  seasons = []
  if type(j.episodes) = "roAssociativeArray" then
    for each k in j.episodes
      seasons.Push(k)
    end for
    seasons.Sort()
    for each sk in seasons
      for each e in j.episodes[sk]
        list.Push({ id: S(e.id), ext: S(e.container_extension), season: sk, num: S(e.episode_num), name: S(e.title) })
      end for
    end for
  else if type(j.episodes) = "roArray" then
    for each grp in j.episodes
      for each e in grp
        list.Push({ id: S(e.id), ext: S(e.container_extension), season: S(e.season), num: S(e.episode_num), name: S(e.title) })
      end for
    end for
  end if
  if list.Count() = 0 then
    setStatus("Sem episódios nessa série.")
    return
  end if
  m.episodes = list
  c = CreateObject("roSGNode", "ContentNode")
  for each e in list
    n = c.CreateChild("ContentNode")
    n.title = "T" + e.season + " E" + e.num + "  -  " + e.name
  end for
  m.eps.content = c
  showEps()
end sub

sub showEps()
  hideAll()
  m.state = "episodes"
  m.title.text = m.seriesName
  m.title.visible = true
  m.eps.visible = true
  m.eps.setFocus(true)
  m.info.text = "OK para assistir  |  Voltar para as séries"
end sub

sub onEpSelect()
  playEpisode(m.eps.itemSelected)
end sub

sub playEpisode(i as integer)
  if i < 0 or i >= m.episodes.Count() then return
  m.epIndex = i
  e = m.episodes[i]
  ext = e.ext
  if ext = "" then ext = "mp4"
  sb = m.sess.base + "/series/" + enc(m.sess.user) + "/" + enc(m.sess.pass) + "/" + e.id
  cands = [{url: sb + "." + ext, fmt: fmtFor(ext)}]
  if LCase(ext) <> "mp4" then cands.Push({url: sb + ".mp4", fmt: "mp4"})
  playList(cands, m.seriesName + " T" + e.season + " E" + e.num)
end sub

' ---------- reprodução ----------
sub playList(cands as object, title as string)
  m.cands = cands
  m.candIdx = 0
  m.playTitle = title
  hideAll()
  m.info.text = ""
  m.prevState = m.state
  m.state = "play"
  startCand()
end sub

sub startCand()
  cd = m.cands[m.candIdx]
  c = CreateObject("roSGNode", "ContentNode")
  c.url = cd.url
  c.title = m.playTitle
  c.streamFormat = cd.fmt
  m.video.content = c
  m.video.visible = true
  m.top.setFocus(true)
  m.video.control = "play"
  m.paused = false
  m.act = ""
  m.skipDone = false
  m.ovTitle.text = m.playTitle
  showOv()
end sub

sub stopVideo()
  hideOv()
  m.video.control = "stop"
  m.video.visible = false
  m.video.content = invalid
  if m.prevState = "episodes" then
    showEps()
  else
    showItems()
  end if
end sub

sub onVideoState()
  st = m.video.state
  if st = "finished" then
    if m.autoNext and m.prevState = "episodes" and m.epIndex + 1 < m.episodes.Count() then
      playEpisode(m.epIndex + 1)
    else
      stopVideo()
    end if
  else if st = "playing" then
    cd = m.cands[m.candIdx]
    if m.kind = "live" and (cd.fmt = "hls" or cd.fmt = "ts") and m.learned <> cd.fmt then
      m.learned = cd.fmt
      m.reg.Write("learned", cd.fmt)
      m.reg.Flush()
    end if
  else if st = "error" then
    if m.candIdx + 1 < m.cands.Count() then
      m.candIdx = m.candIdx + 1
      m.video.control = "stop"
      startCand()
    else
      stopVideo()
      setStatus("Não foi possível reproduzir. Tente outro conteúdo ou mude o Formato do fluxo.")
    end if
  end if
end sub

' ---------- botão Voltar ----------
function onKeyEvent(key as string, press as boolean) as boolean
  if not press then return false
  if m.state = "play" and key <> "back" then
    handlePlayKey(key)
    return true
  end if
  if key = "back" then
    if m.state = "play" then
      stopVideo()
      return true
    else if m.state = "episodes" then
      showItems()
      return true
    else if m.state = "items" then
      showCats()
      return true
    else if m.state = "cats" then
      showMenu()
      return true
    else if m.state = "hidecats" then
      showHideKinds()
      return true
    else if m.state = "hidekind" then
      showSettings()
      return true
    else if m.state = "renewprompt" or m.state = "renewplans" or m.state = "renewqr" then
      closeRenew()
      return true
    else if m.state = "settings" then
      m.unlocked = false
      showMenu()
      return true
    end if
    return false
  end if
  return false
end function

' ---------- configurações ----------
function isHidden(nm as string) as boolean
  arr = m.hide[m.kind]
  if arr = invalid then return false
  for each h in arr
    if h = nm then return true
  end for
  return false
end function

function yesNo(v as boolean) as string
  if v then return "Sim"
  return "Não"
end function

sub showSettings()
  hideAll()
  m.state = "settings"
  m.title.text = "Configurações"
  m.title.visible = true
  c = CreateObject("roSGNode", "ContentNode")
  adult = "Oculto"
  if m.unlocked then adult = "Liberado"
  for each r in ["Formato do fluxo: " + fmtLabel(), "Próximo episódio automático: " + yesNo(m.autoNext), "Alterar PIN (padrão 000)", "Pastas adultas: pedem PIN", "Pastas ocultas", "Refazer reconhecimento deste aparelho", "Tamanho das letras: " + fontName(), "MAC / ID desta TV", "Voltar"]
    n = c.CreateChild("ContentNode")
    n.title = r
  end for
  m.setList.content = c
  m.sample.text = "Prévia: Esta é a sinopse de exemplo. Assim ficam os textos com o tamanho escolhido."
  m.sample.visible = true
  m.setList.visible = true
  m.setList.setFocus(true)
  if m.setIdx <> invalid then m.setList.jumpToItem = m.setIdx
  mac = deviceMac()
  if mac = "" then mac = "(a Roku não informa; veja o ID em MAC / ID desta TV)"
  m.info.text = "MAC da TV: " + mac + "   |   Voltar para o menu"
  if m.setMsg <> invalid then
    setStatus(m.setMsg)
    m.setMsg = invalid
  end if
end sub

sub onSetSelect()
  i = m.setList.itemSelected
  m.setIdx = i
  if i = 0 then
    if m.fmtPref = "auto" then
      m.fmtPref = "hls"
    else if m.fmtPref = "hls" then
      m.fmtPref = "ts"
    else
      m.fmtPref = "auto"
    end if
    m.reg.Write("fmt", m.fmtPref)
    m.reg.Flush()
    showSettings()
  else if i = 1 then
    m.autoNext = not m.autoNext
    if m.autoNext then m.reg.Write("autonext", "1") else m.reg.Write("autonext", "0")
    m.reg.Flush()
    showSettings()
  else if i = 2 then
    askText("PIN atual", "", true, "pincur")
  else if i = 3 then
    m.setMsg = "As pastas adultas aparecem com [PIN] e pedem o PIN para abrir."
    showSettings()
  else if i = 4 then
    showHideKinds()
  else if i = 5 then
    m.learned = ""
    m.reg.Delete("learned")
    m.reg.Flush()
    m.setMsg = "Reconhecimento do aparelho refeito."
    showSettings()
  else if i = 6 then
    m.fontLvl = m.fontLvl + 1
    if m.fontLvl > 2 then m.fontLvl = 0
    m.reg.Write("fontlvl", m.fontLvl.ToStr())
    m.reg.Flush()
    applyFonts()
    showSettings()
  else if i = 7 then
    showDeviceInfo()
  else if i = 8 then
    m.unlocked = false
    showMenu()
  end if
end sub

' MAC / identificação desta TV (o MAC só aparece se a Roku liberar para o canal)
function deviceMac() as string
  di = CreateObject("roDeviceInfo")
  mac = ""
  ci = di.GetConnectionInfo()
  if ci <> invalid and type(ci) = "roAssociativeArray" then
    for each k in ci
      lk = LCase(k)
      if Instr(1, lk, "mac") > 0 then
        v = ci[k]
        if type(v) = "roString" or type(v) = "String" then
          if v <> "" then mac = UCase(v)
        end if
      end if
    end for
  end if
  return mac
end function

sub showDeviceInfo()
  di = CreateObject("roDeviceInfo")
  mac = deviceMac()
  if mac = "" then mac = "não informado pela Roku"
  m.setMsg = "MAC: " + mac + "  |  ID da TV: " + Left(di.GetChannelClientId(), 20) + "  |  Modelo: " + di.GetModelDisplayName()
  showSettings()
end sub

sub onPinInput(field as string, value as string)
  if field = "pincat" then
    if value = m.pin then
      openCatById(m.pendCid, m.pendName)
    else
      setStatus("PIN incorreto.")
      m.cats.setFocus(true)
    end if
    return
  end if
  if field = "pincur" then
    if value <> m.pin then
      m.setMsg = "PIN atual incorreto."
      showSettings()
    else
      askText("Novo PIN (3 a 8 números)", "", false, "pinnew")
    end if
  else if field = "pinnew" then
    re = CreateObject("roRegex", "^[0-9]{3,8}$", "")
    if re.IsMatch(value) then
      m.pin = value
      m.reg.Write("pin", value)
      m.reg.Flush()
      m.setMsg = "PIN alterado."
    else
      m.setMsg = "O PIN precisa ter de 3 a 8 números."
    end if
    showSettings()
  else if field = "pinunlock" then
    if value = m.pin then
      m.unlocked = true
      m.setMsg = "Conteúdo adulto liberado até sair das configurações."
    else
      m.setMsg = "PIN incorreto."
    end if
    showSettings()
  end if
end sub

' Pastas ocultas: escolhe o tipo e marca/desmarca categorias
sub showHideKinds()
  hideAll()
  m.state = "hidekind"
  m.hideEdit = false
  m.title.text = "Pastas ocultas"
  m.title.visible = true
  c = CreateObject("roSGNode", "ContentNode")
  for each r in ["Canais ao vivo", "Filmes", "Séries"]
    n = c.CreateChild("ContentNode")
    n.title = r
  end for
  m.cats.content = c
  m.cats.visible = true
  m.cats.setFocus(true)
  m.hideChoosing = true
  m.cats.unobserveField("itemSelected")
  m.cats.observeField("itemSelected", "onHideKindSelect")
  m.info.text = "Escolha o tipo  |  Voltar para as configurações"
end sub

sub onHideKindSelect()
  i = m.cats.itemSelected
  if i = 0 then
    m.hideKind = "live"
    act = "get_live_categories"
  else if i = 1 then
    m.hideKind = "movie"
    act = "get_vod_categories"
  else
    m.hideKind = "series"
    act = "get_series_categories"
  end if
  m.hideAct = act
  showHideCats(0)
end sub

sub showHideCats(pos as integer)
  arr = m.catCache[m.hideAct]
  if arr = invalid then
    setStatus("Lista ainda não carregada. Tente mais tarde.")
    return
  end if
  hideAll()
  m.state = "hidecats"
  m.hideEdit = true
  m.title.text = "Pastas ocultas - OK marca/desmarca"
  m.title.visible = true
  c = CreateObject("roSGNode", "ContentNode")
  for each cat in arr
    nm = S(cat.category_name)
    if nm <> "" then
      n = c.CreateChild("ContentNode")
      mark = "[  ] "
      for each h in m.hide[m.hideKind]
        if h = nm then mark = "[X] "
      end for
      n.title = mark + nm
      n.addFields({ cname: nm })
    end if
  end for
  m.cats.content = c
  m.cats.unobserveField("itemSelected")
  m.cats.observeField("itemSelected", "onHideToggle")
  m.cats.visible = true
  m.cats.setFocus(true)
  m.cats.jumpToItem = pos
  m.info.text = "OK oculta/mostra  |  Voltar"
end sub

sub onHideToggle()
  i = m.cats.itemSelected
  node = m.cats.content.getChild(i)
  if node = invalid then return
  nm = node.cname
  lst = m.hide[m.hideKind]
  nl = []
  found = false
  for each h in lst
    if h = nm then
      found = true
    else
      nl.Push(h)
    end if
  end for
  if not found then nl.Push(nm)
  m.hide[m.hideKind] = nl
  m.reg.Write("hide", FormatJson(m.hide))
  m.reg.Flush()
  showHideCats(i)
end sub

' ---------- aviso de vencimento e renovação (Pix na TV) ----------
sub checkDueWarning()
  if m.warned then return
  dd = m.sess.dueDays
  if dd = invalid then return
  if dd <= 1 then
    m.warned = true
    if dd <= 0 then
      showRenewPrompt("Seu acesso vence hoje!")
    else
      showRenewPrompt("Seu acesso vence amanhã!")
    end if
  end if
end sub

sub showRenewPrompt(msg as string)
  hideAll()
  m.state = "renewprompt"
  m.qrMode = false
  m.rnMsg.translation = [140, 170]
  if m.canPay then
    m.rnMsg.text = msg + chr(10) + "Renove agora e pague pelo QR Code (Pix) aqui na TV."
  else
    m.rnMsg.text = msg + chr(10) + "Fale com o seu fornecedor para renovar."
  end if
  m.rnMsg.visible = true
  c = CreateObject("roSGNode", "ContentNode")
  if m.canPay then
    n = c.CreateChild("ContentNode")
    n.title = "Renovar agora"
  end if
  n = c.CreateChild("ContentNode")
  n.title = "Fechar"
  m.rnList.content = c
  m.rnList.numRows = 2
  m.rnList.translation = [390, 360]
  m.rnList.visible = true
  m.rnList.setFocus(true)
  m.info.text = "Use as setas e OK do controle"
end sub

sub closeRenew()
  m.poll.control = "stop"
  m.payId = invalid
  if m.expiredLogin = true or m.sess = invalid then
    m.expiredLogin = false
    showLogin("")
  else
    showMenu()
  end if
end sub

sub onRnSelect()
  i = m.rnList.itemSelected
  node = m.rnList.content.getChild(i)
  if node = invalid then return
  t = node.title
  if t = "Fechar" then
    closeRenew()
  else if t = "Renovar agora" then
    setStatus("Buscando planos...")
    callApi(PANEL_URL() + "/api/public/roku/renew", FormatJson({ owner: m.owner, usuario: m.user, senha: m.pass, action: "plans" }), "onPlans")
  else if m.plans <> invalid and i < m.plans.Count() then
    pickPlan(m.plans[i])
  end if
end sub

sub onPlans()
  j = invalid
  if m.task.text <> "" then j = ParseJson(m.task.text)
  if m.task.status <> 200 or j = invalid or j.plans = invalid then
    msg = "Não foi possível buscar os planos."
    if j <> invalid and j.error <> invalid then msg = S(j.error)
    setStatus(msg)
    return
  end if
  setStatus("")
  m.plans = []
  for each p in j.plans
    m.plans.Push({ months: p.months, label: S(p.label), cents: p.priceCents })
  end for
  if m.plans.Count() = 1 then
    pickPlan(m.plans[0])
    return
  end if
  hideAll()
  m.state = "renewplans"
  m.rnMsg.translation = [140, 120]
  m.rnMsg.text = "Escolha o plano para renovar"
  m.rnMsg.visible = true
  c = CreateObject("roSGNode", "ContentNode")
  for each p in m.plans
    n = c.CreateChild("ContentNode")
    n.title = p.label + "  -  R$ " + moneyBr(p.cents)
  end for
  m.rnList.content = c
  m.rnList.numRows = 5
  m.rnList.translation = [390, 220]
  m.rnList.visible = true
  m.rnList.setFocus(true)
  m.info.text = "OK para gerar o Pix  |  Voltar para fechar"
end sub

function moneyBr(cents as integer) as string
  r = cents mod 100
  rs = r.ToStr()
  if r < 10 then rs = "0" + rs
  return Int(cents / 100).ToStr() + "," + rs
end function

sub pickPlan(p as object)
  m.curPlan = p
  setStatus("Gerando o Pix...")
  callApi(PANEL_URL() + "/api/public/roku/renew", FormatJson({ owner: m.owner, usuario: m.user, senha: m.pass, action: "pix", months: p.months }), "onPix")
end sub

sub onPix()
  j = invalid
  if m.task.text <> "" then j = ParseJson(m.task.text)
  if m.task.status <> 200 or j = invalid or j.paymentId = invalid then
    msg = "Não foi possível gerar o Pix agora."
    if j <> invalid and j.error <> invalid then msg = S(j.error)
    setStatus(msg)
    return
  end if
  m.payId = S(j.paymentId)
  ba = CreateObject("roByteArray")
  ba.FromBase64String(S(j.qrCodeBase64))
  path = "tmp:/pix_" + m.payId + ".png"
  ba.WriteFile(path)
  hideAll()
  m.state = "renewqr"
  m.rnMsg.translation = [140, 40]
  m.rnMsg.text = "Pague " + m.curPlan.label + " - R$ " + moneyBr(m.curPlan.cents)
  m.rnMsg.visible = true
  m.qr.uri = path
  m.qrBg.visible = true
  m.qr.visible = true
  c = CreateObject("roSGNode", "ContentNode")
  n = c.CreateChild("ContentNode")
  n.title = "Fechar"
  m.rnList.content = c
  m.rnList.numRows = 1
  m.rnList.translation = [390, 450]
  m.rnList.visible = true
  m.rnList.setFocus(true)
  m.info.text = "Abra o app do banco, escolha Pix > Ler QR Code e aponte para a TV"
  setStatus("Aguardando o pagamento...")
  m.pollCount = 0
  m.poll.control = "start"
end sub

sub onPoll()
  if m.payId = invalid or m.state <> "renewqr" then
    m.poll.control = "stop"
    return
  end if
  m.pollCount = m.pollCount + 1
  if m.pollCount > 360 then
    m.poll.control = "stop"
    setStatus("O QR Code expirou. Feche e gere um novo.")
    return
  end if
  callApi(PANEL_URL() + "/api/public/payment-status/" + m.payId, "", "onPayStatus")
end sub

sub onPayStatus()
  j = invalid
  if m.task.status = 200 and m.task.text <> "" then j = ParseJson(m.task.text)
  if j = invalid or j.status = invalid then return
  st = S(j.status)
  if st = "approved" then
    m.poll.control = "stop"
    m.payId = invalid
    hideAll()
    m.state = "renewdone"
    m.rnMsg.translation = [140, 250]
    m.rnMsg.text = "Pagamento aprovado!" + chr(10) + "Renovando seu acesso..."
    m.rnMsg.visible = true
    m.expiredLogin = false
    m.warned = true
    doLogin()
  else if st = "rejected" or st = "cancelled" or st = "expired" then
    m.poll.control = "stop"
    setStatus("Pagamento não concluído. Feche e tente de novo.")
  end if
end sub

' ---------- controles do player (estilo Netflix) ----------
function fmtT(sec as dynamic) as string
  s = Int(sec)
  if s < 0 then s = 0
  h = Int(s / 3600)
  mi = Int((s mod 3600) / 60)
  se = s mod 60
  r = ""
  if h > 0 then r = h.ToStr() + ":"
  mm = mi.ToStr()
  if h > 0 and mi < 10 then mm = "0" + mm
  ss = se.ToStr()
  if se < 10 then ss = "0" + ss
  if h = 0 then return mm + ":" + ss
  return r + mm + ":" + ss
end function

sub showOv()
  if m.kind = "live" then
    m.ovShade.translation = [0, 500]
    m.ovShade.height = 220
    m.ovShade.visible = true
    m.ovTitle.translation = [80, 440]
    m.ovTitle.visible = true
    m.epgNow.visible = true
    m.epgNext.visible = true
    m.ovTimer.control = "stop"
    m.ovTimer.control = "start"
    return
  end if
  m.ovShade.translation = [0, 560]
  m.ovShade.height = 160
  m.ovTitle.translation = [80, 575]
  m.ovShade.visible = true
  m.ovTitle.visible = true
  m.pbBg.visible = true
  m.pbFill.visible = true
  m.pbTime.visible = true
  m.pbHint.visible = true
  m.ovTimer.control = "stop"
  m.ovTimer.control = "start"
end sub

sub hideOv()
  m.epgNow.visible = false
  m.epgNext.visible = false
  m.ovShade.visible = false
  m.ovTitle.visible = false
  m.pbBg.visible = false
  m.pbFill.visible = false
  m.pbTime.visible = false
  m.pbHint.visible = false
  m.actBg.visible = false
  m.actLabel.visible = false
  m.ovTimer.control = "stop"
end sub

sub onOvHide()
  if m.paused then return
  m.epgNow.visible = false
  m.epgNext.visible = false
  m.ovShade.visible = false
  m.ovTitle.visible = false
  m.pbBg.visible = false
  m.pbFill.visible = false
  m.pbTime.visible = false
  m.pbHint.visible = false
end sub

sub updateBar(pos as dynamic, dur as dynamic)
  if dur = invalid or dur <= 0 then
    m.pbFill.width = 0
    m.pbTime.text = fmtT(pos)
    return
  end if
  w = Int(1120 * pos / dur)
  if w > 1120 then w = 1120
  if w < 0 then w = 0
  m.pbFill.width = w
  m.pbTime.text = fmtT(pos) + " / " + fmtT(dur)
end sub

sub doSeek(delta as integer)
  if m.kind = "live" then return
  pos = m.video.position + delta
  dur = m.video.duration
  if pos < 0 then pos = 0
  if dur > 0 and pos > dur - 2 then pos = dur - 2
  m.video.seek = pos
  updateBar(pos, dur)
  showOv()
end sub

sub handlePlayKey(key as string)
  if key = "left" then
    doSeek(-m.cfg.seek)
  else if key = "right" then
    doSeek(m.cfg.seek)
  else if key = "rewind" then
    doSeek(-m.cfg.seekBig)
  else if key = "fastforward" then
    doSeek(m.cfg.seekBig)
  else if (key = "OK" or key = "play") and m.kind = "live" then
    showOv()
  else if key = "OK" or key = "play" then
    if m.act = "next" then
      playNextEp()
    else if m.act = "intro" then
      skipIntro()
    else
      togglePause()
    end if
  else if key = "up" or key = "down" or key = "info" then
    showOv()
  end if
end sub

sub togglePause()
  if m.paused then
    m.video.control = "resume"
    m.paused = false
    showOv()
  else
    m.video.control = "pause"
    m.paused = true
    showOv()
    m.ovTimer.control = "stop"
  end if
end sub

sub skipIntro()
  p = m.video.position
  target = m.cfg.introEnd
  if p + 10 > target then target = p + 10
  m.skipDone = true
  m.video.seek = target
  m.act = ""
  m.actBg.visible = false
  m.actLabel.visible = false
end sub

sub playNextEp()
  m.act = ""
  m.actBg.visible = false
  m.actLabel.visible = false
  if m.epIndex + 1 < m.episodes.Count() then playEpisode(m.epIndex + 1)
end sub

' roda a cada segundo de vídeo: atualiza a barra, o "Pular abertura" e a contagem do próximo episódio
sub onPos()
  if m.state <> "play" or m.kind = "live" then return
  pos = m.video.position
  dur = m.video.duration
  if m.pbBg.visible then updateBar(pos, dur)
  m.act = ""
  txt = ""
  if m.prevState = "episodes" and dur > 60 then
    rem = dur - pos
    if m.epIndex + 1 < m.episodes.Count() and rem <= m.cfg.nextSecs and rem > 0 then
      m.act = "next"
      n = Int(rem + 0.99)
      if m.autoNext then txt = "Próximo em " + n.ToStr() + "  (OK)" else txt = "Próximo  (OK)"
    else if not m.skipDone and dur > 300 and pos >= m.cfg.introFrom and pos <= m.cfg.introTo then
      m.act = "intro"
      txt = "Pular abertura  (OK)"
    end if
  end if
  if m.act <> "" then
    m.actLabel.text = txt
    m.actBg.visible = true
    m.actLabel.visible = true
  else
    m.actBg.visible = false
    m.actLabel.visible = false
  end if
end sub

' ---------- tamanho das letras ----------
function fontName() as string
  if m.fontLvl = 1 then return "Grande"
  if m.fontLvl = 2 then return "Extra grande"
  return "Normal"
end function

sub applyFonts()
  if m.fontLvl = 2 then
    f1 = "font:LargeBoldSystemFont"
    f2 = "font:LargeSystemFont"
    f3 = "font:MediumBoldSystemFont"
  else if m.fontLvl = 1 then
    f1 = "font:LargeSystemFont"
    f2 = "font:MediumBoldSystemFont"
    f3 = "font:MediumSystemFont"
  else
    f1 = "font:MediumBoldSystemFont"
    f2 = "font:MediumSystemFont"
    f3 = "font:SmallBoldSystemFont"
  end if
  m.info.font = f3
  m.status.font = f2
  m.sample.font = f2
  m.epgNow.font = f1
  m.epgNext.font = f2
  m.ovTitle.font = f2
  m.pbTime.font = f3
  m.actLabel.font = f2
end sub

' ---------- guia (EPG) do canal ao vivo, com letras grandes ----------
sub loadEpg(sid as string)
  m.epgNow.text = "Carregando programação..."
  m.epgNext.text = ""
  t = CreateObject("roSGNode", "ApiTask")
  t.url = apiBase() + "&action=get_short_epg&stream_id=" + enc(sid) + "&limit=3"
  t.body = ""
  t.observeField("status", "onEpg")
  m.epgTask = t
  t.control = "RUN"
end sub

function b64(v as dynamic) as string
  s = S(v)
  if s = "" then return ""
  ba = CreateObject("roByteArray")
  ba.FromBase64String(s)
  return ba.ToAsciiString()
end function

function hhmm(ts as dynamic) as string
  s = S(ts)
  if s = "" then return ""
  dt = CreateObject("roDateTime")
  dt.FromSeconds(Val(s))
  dt.ToLocalTime()
  h = dt.GetHours().ToStr()
  mi = dt.GetMinutes()
  ms = mi.ToStr()
  if mi < 10 then ms = "0" + ms
  return h + ":" + ms
end function

sub onEpg()
  j = invalid
  if m.epgTask.status = 200 then j = ParseJson(m.epgTask.text)
  if j = invalid or j.epg_listings = invalid or j.epg_listings.Count() = 0 then
    m.epgNow.text = "Programação indisponível para este canal"
    m.epgNext.text = ""
    return
  end if
  l = j.epg_listings
  m.epgNow.text = "NO AR " + hhmm(l[0].start_timestamp) + "-" + hhmm(l[0].stop_timestamp) + "  " + b64(l[0].title)
  if l.Count() > 1 then
    m.epgNext.text = "A SEGUIR " + hhmm(l[1].start_timestamp) + "  " + b64(l[1].title)
  else
    m.epgNext.text = ""
  end if
end sub
