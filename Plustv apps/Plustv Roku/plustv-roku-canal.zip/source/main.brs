sub Main(args as dynamic)
  screen = CreateObject("roSGScreen")
  port = CreateObject("roMessagePort")
  screen.setMessagePort(port)
  screen.CreateScene("MainScene")
  screen.show()
  while true
    msg = wait(0, port)
    if type(msg) = "roSGScreenEvent" then
      if msg.isScreenClosed() then return
    end if
  end while
end sub
