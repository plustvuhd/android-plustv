# PlusTV Player - App para TV LG (webOS)

App leve que abre o seu Web Player em modo TV (https://SEU-PAINEL/player?tv=lg). Como o player vem do painel, ele se atualiza sozinho: mudou o painel, mudou na TV, sem reenviar para a LG Content Store (só reenvie se mudar este pacote: ícone, nome, endereço).

Modo TV (já no painel v816): navegação pelas setas do controle, OK = clicar, Voltar da LG, teclas de mídia (play/pause/avançar/retroceder), foco destacado. O controle "mágico" (ponteiro) também funciona. Vale a mesma cobrança por ativos da Roku (cada usuário conta 1x por mês, Roku + LG juntos).

## Arquivos
- appinfo.json  (id com.plustv.player, nome, ícones)
- index.html + config.js  (config.js: PANEL = endereço do painel; OWNER opcional = link do player de um servidor)
- icon.png (80x80), largeIcon.png (130x130), splash.png (1920x1080)

## Gerar o pacote (.ipk)
1. Instale o Node.js e depois: `npm i -g @webos-tools/cli`
2. Dentro da pasta do app: `ares-package .`  (gera com.plustv.player_1.0.0_all.ipk)

## Testar na sua TV LG
1. Na TV, instale o app "Developer Mode" (LG Content Store), abra, faça login com a conta LG Developer e ative "Dev Mode Status" + "Key Server". Anote o IP.
2. No PC: `ares-setup-device` (adicione a TV como "tv", host = IP, porta 9922, usuário prisoner), depois `ares-novacom --device tv --getkey` (digite a passphrase mostrada no app Developer Mode).
3. `ares-install --device tv com.plustv.player_1.0.0_all.ipk` e `ares-launch --device tv com.plustv.player`.
4. Debug: `ares-inspect --device tv --app com.plustv.player --open`.
(O Developer Mode expira em ~50 h; renove no app para continuar testando.)

## Publicar na LG Content Store
1. Cadastre-se como vendedor em seller.lgappstv.com (conta LG Seller Lounge; empresa ou pessoa física, com dados fiscais).
2. Em "Apps" > "Register New App": envie o .ipk, nome, descrição, categoria, classificação indicativa, país/idioma, URL da política de privacidade, ícones e capturas de tela 1920x1080 (confira os tamanhos no formulário).
3. Marque os modelos/versões de webOS que quer atender (o ideal é webOS 4.0 ou mais novo). Informe uma conta de teste (usuário/senha) para a revisão da LG.
4. Faça o "self-check" e envie para QA. A LG testa navegação pelo controle, botão Voltar, saída do app e comportamento sem internet (o app já mostra "Sem conexão" com Tentar de novo/Sair).
5. Aprovado, você escolhe a data de lançamento; novas versões entram pelo mesmo processo (aumente "version" no appinfo.json).

## Atenção
- A LG reprova apps com conteúdo sem licença. Apresente como player: o cliente entra com a conta do próprio provedor; não traz canais.
- App web hospedado (carrega o player do seu painel) costuma ser aceito, mas a LG pode pedir ajustes; por isso a tela de erro offline fica no pacote.
- Nunca testado em uma TV LG real nesta versão. Teste em mais de um modelo/ano (webOS 4/5/6/22+), principalmente a reprodução de canais ao vivo (TS/HLS).

## Endereço de descoberta (mudar de domínio sem reenviar o app)
Veja ../descoberta/LEIA-ME.md. Configure DISCOVERY em config.js antes de gerar o .ipk.
