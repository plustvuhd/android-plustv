// PANEL: endereço padrão do painel (usado se o endereço de descoberta e o último endereço salvo falharem).
// DISCOVERY: arquivo JSON {"panel":"https://..."} num lugar que você nunca troca (domínio curto, Cloudflare Pages, GitHub raw).
//   Se mudar o domínio do painel, edite só esse arquivo - sem enviar novo app para a LG. Deixe "" para desativar.
//   O servidor do arquivo precisa mandar o cabeçalho Access-Control-Allow-Origin: * (Cloudflare Pages e GitHub raw já mandam).
// OWNER (opcional): link do player de um servidor, ex.: "meu-nome".
window.PLUSTV = { PANEL: "https://konnex.business", DISCOVERY: "https://raw.githubusercontent.com/plustvuhd/plustv-config/main/plustv.json", OWNER: "" };
