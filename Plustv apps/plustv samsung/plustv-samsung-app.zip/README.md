# PlusTV Player - App para TVs Samsung (Tizen, 2015 em diante)

Um único pacote que funciona em TVs Samsung de 2015 até as atuais:
- TV moderna (Tizen 5.0 / 2019 em diante): o app abre o seu Web Player completo (https://SEU-PAINEL/player?tv=samsung) em modo TV - atualiza sozinho pelo painel, sem reenviar para a loja.
- TV antiga (Tizen 2.3 a 4.0 / 2015-2018): o app abre automaticamente o modo "lite" (dentro do pacote): login, carregamento com progresso, Canais/Filmes/Séries em listas, EPG grande, pular abertura, próximo episódio, Pix na TV, configurações (formato do fluxo, próximo automático, tamanho das letras, MAC) e player nativo AVPlay. Tudo pelo controle remoto.
- TVs Samsung de 2010 a 2014 (plataforma Orsay/Smart Hub antigo) NÃO são suportadas: a Samsung encerrou essa plataforma e não aceita mais apps nela.

Cobrança: o login pelo app (modo web ou lite) conta como ativo de TV do mês (mesma contagem de Roku e LG).
Endereço do painel: descoberta pelo GitHub (config.js, campo DISCOVERY) com o endereço padrão como reserva.

## Arquivos
config.xml (identificação e permissões), index.html, boot.js (descoberta + escolha moderna/lite), lite.js/lite.css (modo lite), config.js, icon.png (117x117).

## Gerar o pacote (.wgt)
1. Instale o Tizen Studio (com "TV Extensions") e o Certificate Manager: crie um certificado de autor e um certificado de distribuidor Samsung (conta Samsung Developer). A TV de teste precisa estar cadastrada no certificado de distribuidor (DUID).
2. File > Import > Tizen > Tizen Project, escolha esta pasta. Botão direito no projeto > Build Signed Package (gera PlusTVPlayer.wgt).
   (Linha de comando: `tizen package -t wgt -s SEU_PERFIL -- .`)

## Testar na sua TV Samsung
1. Na TV: Apps > digite 12345 > ligue o "Developer mode" e informe o IP do seu PC. Reinicie a TV.
2. No Tizen Studio: Device Manager > conecte à TV (IP da TV). Run As > Tizen Web Application (ou instale o .wgt).
3. Para testar o modo lite numa TV nova, abra o app e (para teste) mude em boot.js a função modern() para retornar false.

## Publicar na Samsung TV (Seller Office)
1. Cadastre-se em seller.samsungapps.com (Samsung Seller Office > TV): conta de vendedor com dados da empresa/pessoa.
2. Em "Add New Application": categoria, nome, descrição, país/idioma, classificação, URL da política de privacidade, ícones e capturas 1920x1080 (confira os tamanhos no formulário).
3. Envie o .wgt assinado (assinatura de distribuidor Samsung gerada pelo Seller Office - o app é reassinado na publicação), informe conta de teste (usuário/senha) e passos de uso.
4. Passa pelo teste da Samsung (navegação por controle, Voltar, sem internet, teclas de mídia). Aprovado, publica.

## Atenção
- A Samsung reprova apps com conteúdo sem licença: apresente como player; o cliente entra com a conta do provedor.
- Esta versão nunca rodou numa TV real. Teste em pelo menos uma TV antiga (2016-2018) e uma moderna (2020+), principalmente a reprodução ao vivo (TS/HLS) no AVPlay.
- No modo lite as pastas adultas aparecem com [PIN] e pedem o PIN (padrão 000, alterável em Configurações) para abrir. Não há "pastas ocultas" por escolha do cliente.
