// Inicialização: acha o painel (descoberta > último que funcionou > padrão), registra as teclas de mídia e escolhe:
// TV moderna (Tizen 5+/2019 em diante) -> abre o Web Player completo; TV antiga -> app "lite" (mesmo login, listas e player nativo AVPlay).
(function () {
  var cfg = window.PLUSTV || {};
  var owner = String(cfg.OWNER || '').trim();
  var boot = document.getElementById('boot');
  var err = document.getElementById('err');
  function clean(u) { u = String(u || '').replace(/^\s+|\s+$/g, '').replace(/\/+$/, ''); return /^https:\/\//.test(u) ? u : ''; }
  function exitApp() { try { tizen.application.getCurrentApplication().exit(); } catch (e) { try { window.close(); } catch (e2) {} } }
  function ls(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function xhr(url, ms, cb) {
    var x = new XMLHttpRequest(), done = false;
    var t = setTimeout(function () { if (!done) { done = true; try { x.abort(); } catch (e) {} cb(0, ''); } }, ms);
    x.onreadystatechange = function () { if (x.readyState === 4 && !done) { done = true; clearTimeout(t); cb(x.status, x.responseText); } };
    try { x.open('GET', url, true); x.send(); } catch (e) { if (!done) { done = true; clearTimeout(t); cb(0, ''); } }
  }
  function discover(cb) {
    var d = String(cfg.DISCOVERY || '');
    if (!d || d.indexOf('SEU-DOMINIO') >= 0) return cb('');
    xhr(d + (d.indexOf('?') < 0 ? '?' : '&') + 't=' + new Date().getTime(), 6000, function (st, txt) {
      var p = '';
      try { if (st === 200) p = clean(JSON.parse(txt).panel); } catch (e) {}
      cb(p);
    });
  }
  function alive(p, cb) { xhr(p + '/api/public/roku/config', 8000, function (st) { cb(st === 200); }); }
  function modern() {
    try {
      return !!(window.IntersectionObserver && window.Promise && window.fetch && Array.prototype.includes && Object.entries && window.CSS && CSS.supports && CSS.supports('display', 'grid'));
    } catch (e) { return false; }
  }
  function registerKeys() {
    try {
      var names = ['MediaPlay', 'MediaPause', 'MediaPlayPause', 'MediaStop', 'MediaFastForward', 'MediaRewind', 'ColorF0Red', 'ColorF1Green', 'ColorF2Yellow', 'ColorF3Blue'];
      for (var i = 0; i < names.length; i++) { try { tizen.tvinputdevice.registerKey(names[i]); } catch (e) {} }
    } catch (e) {}
  }
  function go() {
    err.style.display = 'none'; boot.style.display = 'flex';
    discover(function (found) {
      var list = [], c = [found, clean(ls('plustv_panel')), clean(cfg.PANEL)];
      for (var i = 0; i < c.length; i++) if (c[i] && list.indexOf(c[i]) < 0) list.push(c[i]);
      var k = 0;
      (function next() {
        if (k >= list.length) { boot.style.display = 'none'; err.style.display = 'flex'; document.getElementById('retry').focus(); return; }
        var p = list[k++];
        alive(p, function (ok) {
          if (!ok) return next();
          try { localStorage.setItem('plustv_panel', p); } catch (e) {}
          window.__panel = p; window.__owner = owner;
          registerKeys();
          if (modern()) window.location.replace(p + '/player' + (owner ? '/' + encodeURIComponent(owner) : '') + '?tv=samsung');
          else { boot.style.display = 'none'; window.PlusLite.start(p, owner); }
        });
      })();
    });
  }
  document.getElementById('retry').onclick = go;
  document.getElementById('exit').onclick = exitApp;
  document.addEventListener('keydown', function (e) {
    if (err.style.display === 'flex') {
      if (e.keyCode === 10009 || e.keyCode === 27) exitApp();
      if (e.keyCode === 37 || e.keyCode === 39) { var a = document.activeElement; (a && a.id === 'retry' ? document.getElementById('exit') : document.getElementById('retry')).focus(); }
    }
  });
  go();
})();
