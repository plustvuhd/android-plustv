// PANEL: endereço padrão do painel (usado se a descoberta e o último endereço salvo falharem).
// DISCOVERY: arquivo JSON {"panel":"https://..."} num lugar fixo (GitHub raw). Mudou o domínio? Edite só esse arquivo.
// OWNER (opcional): link do player de um servidor.
window.PLUSTV = { PANEL: "https://konnex.business", DISCOVERY: "https://raw.githubusercontent.com/plustvuhd/plustv-config/main/plustv.json", OWNER: "" };
