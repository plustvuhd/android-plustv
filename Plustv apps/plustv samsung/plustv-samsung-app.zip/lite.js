// PlusTV Player - modo "lite" para TVs Samsung antigas (Tizen 2.3 a 4.0, 2015-2018). ES5 puro + player nativo AVPlay.
// Mesmo login e mesmas regras do canal Roku (usa /api/public/roku/*). Controle remoto: setas, OK, Voltar, teclas de mídia.
window.PlusLite = (function () {
  var P = '', OWNER = '';
  var app = document.getElementById('app');
  var S = { owner: '', user: '', pass: '', fmt: 'auto', learned: '', autoNext: true, font: 0, hide: { live: [], movie: [], series: [] } };
  var CFG = { notice: '', maintenance: false, maintenanceMsg: '', introFrom: 3, introTo: 150, introEnd: 90, seek: 10, seekBig: 30, nextSecs: 10 };
  var sess = null, view = null, stack = [], kind = 'live', heading = '', catName = '', seriesName = '';
  var episodes = [], epIdx = 0, warned = false, canPay = false, expiredLogin = false;
  var adultRe = /adult|xxx|\+\s?18|18\s?\+|porn|sexo|sexy|putaria|playboy|brazzers|er.tic/i;

  function ls(k) { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function enc(s) { return encodeURIComponent(s); }
  function toStr(v) { return v == null ? '' : String(v); }
  function setFont() { document.documentElement.style.fontSize = (24 + S.font * 3) + 'px'; }

  function xhr(method, url, body, cb, ms) {
    var x = new XMLHttpRequest(), done = false;
    var t = setTimeout(function () { if (!done) { done = true; try { x.abort(); } catch (e) {} cb(0, ''); } }, ms || 30000);
    x.onreadystatechange = function () { if (x.readyState === 4 && !done) { done = true; clearTimeout(t); cb(x.status, x.responseText); } };
    try { x.open(method, url, true); if (body) x.setRequestHeader('Content-Type', 'application/json'); x.send(body || null); } catch (e) { if (!done) { done = true; clearTimeout(t); cb(0, ''); } }
  }
  function jparse(t) { try { return JSON.parse(t); } catch (e) { return null; } }
  function api(action, extra, cb) {
    xhr('GET', sess.base + '/player_api.php?username=' + enc(sess.user) + '&password=' + enc(sess.pass) + '&action=' + action + (extra || ''), null, function (st, txt) { cb(st === 200 ? jparse(txt) : null); });
  }
  function post(path, obj, cb) { xhr('POST', P + path, JSON.stringify(obj), function (st, txt) { cb(st, jparse(txt)); }); }

  // ---------- estrutura de tela ----------
  function shell(title, info) {
    app.style.display = 'block';
    app.innerHTML = '<div class="hd"></div><div class="title">' + esc(title) + '</div><div id="body"></div><div class="status" id="status"></div><div class="info" id="info">' + esc(info || '') + '</div>';
  }
  function status(t) { var e = document.getElementById('status'); if (e) e.textContent = t || ''; }
  function infoTxt(t) { var e = document.getElementById('info'); if (e) e.textContent = t || ''; }
  function go(v) { if (view) stack.push(view); view = v; v.show(); }
  function replace(v) { view = v; v.show(); }
  function back() { if (stack.length) { view = stack.pop(); view.show(); } else if (view && view.root) { exit(); } }
  function exit() { try { tizen.application.getCurrentApplication().exit(); } catch (e) { try { window.close(); } catch (e2) {} } }

  // Lista com janela de linhas (leve para TVs antigas)
  function makeList(opts) {
    var L = { items: opts.items, idx: opts.idx || 0, top: 0, rows: opts.rows || 11 };
    L.render = function () {
      var b = document.getElementById('body'); if (!b) return;
      if (L.idx < L.top) L.top = L.idx;
      if (L.idx >= L.top + L.rows) L.top = L.idx - L.rows + 1;
      var h = '<div class="list' + (opts.cls ? ' ' + opts.cls : '') + '"' + (opts.style ? ' style="' + opts.style + '"' : '') + '>';
      for (var i = L.top; i < Math.min(L.items.length, L.top + L.rows); i++) {
        var it = L.items[i];
        h += '<div class="row' + (i === L.idx ? ' sel' : '') + '">' + (it.img ? '<img src="' + esc(it.img) + '" onerror="this.style.visibility=\'hidden\'">' : '') + esc(it.label) + '</div>';
      }
      b.innerHTML = h + '</div>';
    };
    L.key = function (c) {
      if (c === 38 && L.idx > 0) { L.idx--; L.render(); return true; }
      if (c === 40 && L.idx < L.items.length - 1) { L.idx++; L.render(); return true; }
      if (c === 33 || c === 427) { L.idx = Math.max(0, L.idx - L.rows); L.render(); return true; }
      if (c === 34 || c === 428) { L.idx = Math.min(L.items.length - 1, L.idx + L.rows); L.render(); return true; }
      if (c === 13) { if (opts.onSelect) opts.onSelect(L.idx, L.items[L.idx]); return true; }
      return false;
    };
    return L;
  }

  // ---------- login ----------
  var loginView = {
    root: true, focus: 0,
    show: function () {
      shell('', 'Use as setas e OK. Preencha e escolha ENTRAR');
      document.getElementById('body').innerHTML = '<div class="center"><img class="logo" src="' + esc(T.logo || 'icon.png') + '"><input class="field" id="f0" placeholder="Código do player (opcional)" value="' + esc(S.owner) + '"><input class="field" id="f1" placeholder="Usuário" value="' + esc(S.user) + '"><input class="field" id="f2" type="password" placeholder="Senha" value="' + esc(S.pass) + '"><button class="btn" id="f3" style="margin:0">ENTRAR</button></div>';
      this.focus = 0; this.fo();
      if (CFG.notice) status(CFG.notice);
    },
    fo: function () { var e = document.getElementById('f' + this.focus); if (e) e.focus(); },
    key: function (c, e) {
      var a = document.activeElement, typing = a && a.tagName === 'INPUT';
      if (c === 40 || c === 38) { this.focus = Math.max(0, Math.min(3, this.focus + (c === 40 ? 1 : -1))); this.fo(); return true; }
      if (c === 13 && this.focus === 3) { this.submit(); return true; }
      if (typing && (c === 37 || c === 39)) return false; // mexe no cursor
      return false;
    },
    submit: function () {
      S.owner = document.getElementById('f0').value.replace(/^\s+|\s+$/g, '');
      S.user = document.getElementById('f1').value.replace(/^\s+|\s+$/g, '');
      S.pass = document.getElementById('f2').value.replace(/^\s+|\s+$/g, '');
      if (!S.user || !S.pass) { status('Informe usuário e senha.'); return; }
      doLogin();
    }
  };

  function doLogin() {
    shell('', ''); status('Entrando...');
    post('/api/public/roku/login', { owner: S.owner, usuario: S.user, senha: S.pass, platform: 'samsung' }, function (st, j) {
      if (j && j.expired) { canPay = j.canPay === true; expiredLogin = true; renewPrompt('Seu acesso venceu.'); return; }
      if (st !== 200 || !j || j.ok !== true) {
        var m = (j && j.error) || 'Não foi possível entrar.'; if (st === 0) m = 'Sem conexão com o servidor. Tente de novo.';
        stack = []; replace(loginView); status(m); return;
      }
      if (j.color1 && validHex(j.color1)) { T.c1 = j.color1; if (j.color2 && validHex(j.color2)) T.c2 = j.color2; if (j.logo && !T.logo) T.logo = toStr(j.logo); applyTheme(); }
      sess = { base: (j.https === true ? 'https' : 'http') + '://' + toStr(j.host), user: toStr(j.user), pass: toStr(j.pass), due: toStr(j.due), dueDays: j.dueDays, name: toStr(j.name) };
      canPay = j.canPay === true; expiredLogin = false;
      lsSet('owner', S.owner); lsSet('user', S.user); lsSet('pass', S.pass);
      preload();
    });
  }

  // ---------- carregando conteúdos antes do menu ----------
  var cache = {};
  function preload() {
    cache = {}; stack = []; view = null;
    var acts = ['get_live_categories', 'get_vod_categories', 'get_series_categories'], names = ['Canais', 'Filmes', 'Séries'], step = 0;
    shell('Carregando conteúdos...', '');
    function draw() {
      var pct = Math.min(100, Math.round(step / 3 * 100 + (step < 3 ? 8 : 0)));
      var t = ''; for (var i = 0; i < 3; i++) t += (step > i ? 'OK ' : step === i ? '... ' : '') + names[i] + '        ';
      document.getElementById('body').innerHTML = '<div class="center" style="top:380px"><div style="height:18px;background:#2a2250;border-radius:9px"><div style="height:18px;width:' + pct + '%;background:#f92085;border-radius:9px"></div></div><div style="text-align:center;margin-top:30px;font-size:1.3rem">' + t + '</div></div>';
    }
    draw();
    (function next() {
      api(acts[step], '', function (arr) {
        if (arr && arr.length !== undefined) cache[acts[step]] = arr;
        step++; draw();
        if (step >= 3) { replace(menuView); checkDue(); } else next();
      });
    })();
  }

  // ---------- tema (logo e cores do dono do player) ----------
  var T = { c1: '#f92085', c2: '#9a2ed6', logo: '', bg: '', title: '' };
  function validHex(c) { return /^#[0-9a-fA-F]{6}$/.test(c || '') ? c : ''; }
  function applyTheme() {
    var st = document.getElementById('theme'); if (!st) { st = document.createElement('style'); st.id = 'theme'; document.head.appendChild(st); }
    var g = 'linear-gradient(to right,' + T.c1 + ',' + T.c2 + ')';
    st.textContent = '.hd{background:' + g + '}.row.sel{background:' + T.c1 + '}.tile.sel,.gcell.sel .pos,.btn.sel,.btn:focus{background:' + g + '}.bar i{background:' + T.c1 + '}.field:focus{border-color:' + T.c1 + '}button{background:' + g + '}.gcell.sel .pos{box-shadow:0 0 0 6px #fff}' +
      (T.bg ? 'body:not(.playing){background:linear-gradient(rgba(11,10,20,.82),rgba(11,10,20,.94)),url(' + T.bg + ') center/cover}' : '');
  }
  function loadTheme(cb) {
    xhr('GET', P + '/api/public/player-config' + (S.owner ? '?owner=' + enc(S.owner) : ''), null, function (st, txt) {
      var j = st === 200 ? jparse(txt) : null;
      if (j) { T.c1 = validHex(j.color1) || T.c1; T.c2 = validHex(j.color2) || T.c2; T.logo = toStr(j.logo); T.bg = toStr(j.bg); T.title = toStr(j.title); applyTheme(); }
      cb();
    }, 8000);
  }

  // ---------- menu (cartões como no Web Player) ----------
  var menuView = {
    root: true, idx: 0,
    show: function () {
      shell('', sess.due ? 'Vencimento ' + sess.due : '');
      var defs = [['Canais', 'Ao vivo', 'TV'], ['Filmes', 'Catálogo', 'F'], ['Séries', 'Temporadas', 'S'], ['Configurações', 'Player, PIN e letras', '*']];
      var h = '<div style="position:absolute;left:0;top:40px;width:1920px;text-align:center">' + (T.logo ? '<img src="' + esc(T.logo) + '" style="max-width:420px;max-height:220px">' : '<div style="font-size:2.4rem;font-weight:bold">' + esc(T.title || 'PlusTV Player') + '</div>') + '</div><div class="tiles">';
      for (var i = 0; i < defs.length; i++) h += '<div class="tile' + (i === this.idx ? ' sel' : '') + '"><div class="badge">' + defs[i][2] + '</div><b>' + defs[i][0] + '</b><span>' + defs[i][1] + '</span></div>';
      h += '</div><div class="logout' + (this.idx === 4 ? ' sel' : '') + '">Sair desta conta</div>';
      document.getElementById('body').innerHTML = h;
      if (CFG.notice) status(CFG.notice);
    },
    key: function (c) {
      if (c === 37 && this.idx > 0 && this.idx < 4) this.idx--;
      else if (c === 39 && this.idx < 3) this.idx++;
      else if (c === 40 && this.idx < 4) this.idx = 4;
      else if (c === 38 && this.idx === 4) this.idx = 0;
      else if (c === 13) { this.sel(this.idx); return true; }
      else return false;
      this.show(); return true;
    },
    sel: function (i) {
      if (i === 3) { go(settingsView); return; }
      if (i === 4) { lsSet('pass', ''); S.pass = ''; sess = null; stack = []; view = null; replace(loginView); return; }
      kind = ['live', 'movie', 'series'][i]; heading = ['Canais ao vivo', 'Filmes', 'Séries'][i];
      var act = ['get_live_categories', 'get_vod_categories', 'get_series_categories'][i];
      var arr = cache[act];
      if (arr) { go(makeBrowse(arr)); return; }
      status('Carregando...'); api(act, '', function (a) { if (a) { cache[act] = a; go(makeBrowse(a)); } else status('Não consegui carregar a lista agora.'); });
    }
  };

  function hidden(nm) { var h = S.hide[kind] || []; for (var i = 0; i < h.length; i++) if (h[i] === nm) return true; return false; }

  // ---------- pastas à esquerda + capas à direita ----------
  var COLS = 6, GROWS = 3;
  function makeBrowse(arr) {
    var cats = [];
    for (var i = 0; i < arr.length; i++) {
      var nm = toStr(arr[i].category_name);
      if (nm && !hidden(nm)) { var ad = adultRe.test(nm); cats.push({ label: ad ? '[PIN] ' + nm : nm, name: nm, adult: ad, cid: toStr(arr[i].category_id) }); }
    }
    var B = { zone: 'cats', ci: 0, ctop: 0, items: [], gi: 0, gtop: 0, loaded: '' };
    var poster = kind !== 'live';
    B.show = function () {
      shell(heading, 'Setas navegam  |  OK abre  |  Voltar: ' + (B.zone === 'grid' ? 'pastas' : 'menu'));
      document.getElementById('body').innerHTML = '<div id="cats" class="cats"></div><div id="grid" class="grid"></div>';
      B.drawCats(); B.drawGrid();
    };
    B.drawCats = function () {
      var rows = 11; if (B.ci < B.ctop) B.ctop = B.ci; if (B.ci >= B.ctop + rows) B.ctop = B.ci - rows + 1;
      var h = ''; for (var i = B.ctop; i < Math.min(cats.length, B.ctop + rows); i++) h += '<div class="row' + (i === B.ci ? (B.zone === 'cats' ? ' sel' : ' cur') : (cats[i].name === B.loaded ? ' cur' : '')) + '">' + esc(cats[i].label) + '</div>';
      document.getElementById('cats').innerHTML = h;
    };
    B.drawGrid = function () {
      var el = document.getElementById('grid'); if (!el) return;
      if (!B.items.length) { el.innerHTML = '<div class="empty">' + (B.loaded ? 'Pasta vazia.' : 'Escolha uma pasta e aperte OK') + '</div>'; return; }
      var h = '', i;
      if (poster) {
        var row = Math.floor(B.gi / COLS), trow = Math.floor(B.gtop / COLS);
        if (row < trow) trow = row; if (row >= trow + GROWS) trow = row - GROWS + 1; B.gtop = trow * COLS;
        for (i = B.gtop; i < Math.min(B.items.length, B.gtop + COLS * GROWS); i++) {
          var it = B.items[i];
          h += '<div class="gcell' + (i === B.gi && B.zone === 'grid' ? ' sel' : '') + '"><div class="pos">' + (it.img ? '<img src="' + esc(it.img) + '" onerror="this.style.display=\'none\'">' : '') + '<span>' + esc(it.label) + '</span></div><div class="nm">' + esc(it.label) + '</div></div>';
        }
      } else {
        var rows = 11; if (B.gi < B.gtop) B.gtop = B.gi; if (B.gi >= B.gtop + rows) B.gtop = B.gi - rows + 1;
        for (i = B.gtop; i < Math.min(B.items.length, B.gtop + rows); i++) h += '<div class="row' + (i === B.gi && B.zone === 'grid' ? ' sel' : '') + '">' + (B.items[i].img ? '<img src="' + esc(B.items[i].img) + '" onerror="this.style.visibility=\'hidden\'">' : '') + esc(B.items[i].label) + '</div>';
      }
      el.innerHTML = h;
    };
    B.key = function (c) {
      if (B.zone === 'cats') {
        if (c === 38 && B.ci > 0) B.ci--; else if (c === 40 && B.ci < cats.length - 1) B.ci++;
        else if (c === 39 && B.items.length) { B.zone = 'grid'; B.show(); return true; }
        else if (c === 13) { B.open(cats[B.ci]); return true; } else return false;
        B.drawCats(); return true;
      }
      var cols = poster ? COLS : 1;
      if (c === 37) { if (!poster || B.gi % cols === 0) { B.zone = 'cats'; B.show(); return true; } B.gi--; }
      else if (c === 39) { if (poster && B.gi < B.items.length - 1) B.gi++; }
      else if (c === 38) { if (B.gi - cols >= 0) B.gi -= cols; }
      else if (c === 40) { B.gi = Math.min(B.items.length - 1, B.gi + cols); }
      else if (c === 13) { pick(B.items[B.gi]); return true; }
      else return false;
      B.drawGrid(); return true;
    };
    B.back = function () { if (B.zone === 'grid') { B.zone = 'cats'; B.show(); } else back(); };
    B.open = function (cat) {
      if (cat.adult) { askPin('PIN para abrir a pasta', function (ok) { if (ok) B.load(cat); else status('PIN incorreto.'); }); return; }
      B.load(cat);
    };
    B.load = function (cat) {
      catName = cat.name; status('Carregando ' + cat.name + '...');
      var act = kind === 'live' ? 'get_live_streams' : kind === 'movie' ? 'get_vod_streams' : 'get_series';
      api(act, '&category_id=' + enc(cat.cid), function (arr) {
        if (!arr) { status('Não consegui abrir essa pasta.'); return; }
        var items = [];
        for (var i = 0; i < arr.length; i++) {
          var it = arr[i];
          if (kind === 'series') items.push({ label: toStr(it.name), img: toStr(it.cover), sid: toStr(it.series_id), ext: '' });
          else items.push({ label: toStr(it.name), img: toStr(it.stream_icon), sid: toStr(it.stream_id), ext: toStr(it.container_extension) || (kind === 'live' ? 'ts' : 'mp4') });
        }
        B.items = items; B.loaded = cat.name; B.gi = 0; B.gtop = 0; B.zone = items.length ? 'grid' : 'cats'; B.show();
      });
    };
    return B;
  }

  function urlFor(k, sid, ext) { return sess.base + '/' + k + '/' + enc(sess.user) + '/' + enc(sess.pass) + '/' + sid + (ext ? '.' + ext : ''); }

  function pick(it) {
    if (kind === 'live') {
      var first = S.fmt === 'auto' ? (S.learned === 'ts' ? 'ts' : 'hls') : S.fmt;
      var hls = { url: urlFor('live', it.sid, 'm3u8'), fmt: 'hls' }, ts = { url: urlFor('live', it.sid, 'ts'), fmt: 'ts' };
      play(first === 'ts' ? [ts, hls] : [hls, ts], it.label, true, it.sid);
      return;
    }
    status('Carregando...');
    if (kind === 'movie') api('get_vod_info', '&vod_id=' + enc(it.sid), function (j) { status(''); detail(it, j && j.info ? j.info : {}, null); });
    else api('get_series_info', '&series_id=' + enc(it.sid), function (j) {
      if (!j || !j.episodes) { status('Não encontrei episódios.'); return; }
      var list = [], seasons = [], k;
      if (j.episodes.length === undefined) { for (k in j.episodes) seasons.push(k); seasons.sort(function (a, b) { return a - b; }); for (var s = 0; s < seasons.length; s++) { var g = j.episodes[seasons[s]]; for (var q = 0; q < g.length; q++) list.push({ id: toStr(g[q].id), ext: toStr(g[q].container_extension) || 'mp4', season: seasons[s], num: toStr(g[q].episode_num), name: toStr(g[q].title) }); } }
      else { for (var a = 0; a < j.episodes.length; a++) for (var b2 = 0; b2 < j.episodes[a].length; b2++) { var e = j.episodes[a][b2]; list.push({ id: toStr(e.id), ext: toStr(e.container_extension) || 'mp4', season: toStr(e.season), num: toStr(e.episode_num), name: toStr(e.title) }); } }
      if (!list.length) { status('Sem episódios nessa série.'); return; }
      status(''); seriesName = it.label; episodes = list; detail(it, j.info || {}, list);
    });
  }

  // Página de detalhes: capa grande, título, dados e sinopse (+ episódios nas séries)
  function detail(it, info, eps) {
    var idx = 0, top = 0, rows = 5;
    var items = []; if (eps) for (var i = 0; i < eps.length; i++) items.push('T' + eps[i].season + ' E' + eps[i].num + '  -  ' + eps[i].name); else items.push('Assistir');
    var meta = []; var y = toStr(info.releasedate || info.releaseDate || info.year).slice(0, 4); if (y) meta.push(y); if (info.duration) meta.push(toStr(info.duration)); if (info.genre) meta.push(toStr(info.genre));
    var rating = Number(info.rating || info.rating_5based * 2 || 0);
    var v = {
      show: function () {
        shell('', 'OK para assistir  |  Voltar');
        if (idx < top) top = idx; if (idx >= top + rows) top = idx - rows + 1;
        var h = '<div class="dposter">' + (it.img ? '<img src="' + esc(it.img) + '">' : '') + '</div><div class="dtext"><div class="dt">' + esc(it.label) + '</div><div class="dm">' + esc(meta.join('  ·  ')) + (rating > 0 ? '  ·  ★ ' + rating.toFixed(1) : '') + '</div><div class="dp">' + esc(toStr(info.plot || info.description) || 'Sinopse não disponível.') + '</div>';
        if (info.cast) h += '<div class="dm" style="margin-top:12px">Elenco: ' + esc(toStr(info.cast).slice(0, 160)) + '</div>';
        h += '</div><div class="dlist">';
        for (var i2 = top; i2 < Math.min(items.length, top + rows); i2++) h += '<div class="row' + (i2 === idx ? ' sel' : '') + '">' + esc(items[i2]) + '</div>';
        document.getElementById('body').innerHTML = h + '</div>';
      },
      key: function (c) {
        if (c === 38 && idx > 0) idx--; else if (c === 40 && idx < items.length - 1) idx++;
        else if (c === 13) { if (eps) playEp(idx); else { var cs = [{ url: urlFor('movie', it.sid, it.ext), fmt: it.ext }]; if (it.ext.toLowerCase() !== 'mp4') cs.push({ url: urlFor('movie', it.sid, 'mp4'), fmt: 'mp4' }); play(cs, it.label, false, ''); } return true; }
        else return false;
        this.show(); return true;
      }
    };
    go(v);
  }
  function playEp(i) {
    if (i < 0 || i >= episodes.length) return;
    epIdx = i; var e = episodes[i], c = [{ url: urlFor('series', e.id, e.ext), fmt: e.ext }];
    if (e.ext.toLowerCase() !== 'mp4') c.push({ url: urlFor('series', e.id, 'mp4'), fmt: 'mp4' });
    play(c, seriesName + ' T' + e.season + ' E' + e.num, false, '', true);
  }

  // ---------- PIN (pastas adultas) ----------
  function getPin() { return ls('pin') || '000'; }
  function askInput(title, cb) {
    var v = {
      show: function () {
        shell(title, 'Digite e aperte OK  |  Voltar: cancelar');
        document.getElementById('body').innerHTML = '<div class="center" style="top:360px"><input class="field" id="pinf" type="password" maxlength="8" placeholder="Digite aqui"></div>';
        var f = document.getElementById('pinf'); f.focus();
      },
      key: function (c) { if (c === 13) { var val = document.getElementById('pinf').value; back(); cb(val); return true; } return false; }
    };
    go(v);
  }
  function askPin(title, cb) { askInput(title, function (val) { cb(val === getPin()); }); }
  function changePin() {
    askInput('PIN atual', function (cur) {
      if (cur !== getPin()) { settingsView.msg = 'PIN atual incorreto.'; settingsView.show(); return; }
      askInput('Novo PIN (3 a 8 números)', function (nw) {
        if (/^[0-9]{3,8}$/.test(nw)) { lsSet('pin', nw); settingsView.msg = 'PIN alterado.'; } else settingsView.msg = 'O PIN precisa ter de 3 a 8 números.';
        settingsView.show();
      });
    });
  }

  // ---------- configurações ----------
  var settingsView = {
    show: function () {
      shell('Configurações', 'OK para alterar  |  Voltar: menu');
      var fmt = S.fmt === 'hls' ? 'HLS (m3u8)' : S.fmt === 'ts' ? 'TS' : 'Automático';
      var fs = ['Normal', 'Grande', 'Extra grande'][S.font];
      var items = [{ label: 'Formato do fluxo: ' + fmt }, { label: 'Próximo episódio automático: ' + (S.autoNext ? 'Sim' : 'Não') }, { label: 'Tamanho das letras: ' + fs }, { label: 'Alterar PIN das pastas adultas (padrão 000)' }, { label: 'Refazer reconhecimento deste aparelho' }, { label: 'MAC / ID desta TV' }, { label: 'Voltar' }];
      this.L = makeList({ items: items, rows: 8, idx: this.idx || 0, onSelect: function (i) { settingsView.sel(i); } });
      this.L.render();
      var b = document.getElementById('body'); b.innerHTML += '<div style="position:absolute;left:80px;top:700px;width:1760px;font-size:1.2rem">Prévia: Esta é a sinopse de exemplo. Assim ficam os textos com o tamanho escolhido.</div>';
      if (this.msg) { status(this.msg); this.msg = ''; }
    },
    key: function (c) { var r = this.L.key(c); this.idx = this.L.idx; return r; },
    sel: function (i) {
      if (i === 0) { S.fmt = S.fmt === 'auto' ? 'hls' : S.fmt === 'hls' ? 'ts' : 'auto'; lsSet('fmt', S.fmt); }
      else if (i === 1) { S.autoNext = !S.autoNext; lsSet('autonext', S.autoNext ? '1' : '0'); }
      else if (i === 2) { S.font = (S.font + 1) % 3; lsSet('font', String(S.font)); setFont(); }
      else if (i === 3) { changePin(); return; }
      else if (i === 4) { S.learned = ''; lsSet('learned', ''); this.msg = 'Reconhecimento do aparelho refeito.'; }
      else if (i === 5) { var mac = ''; try { mac = webapis.network.getMac(); } catch (e) {} var id = ''; try { id = webapis.productinfo.getDuid(); } catch (e2) {} this.msg = 'MAC: ' + (mac || 'não informado pela Samsung') + (id ? '  |  ID: ' + id : ''); }
      else { back(); return; }
      this.show();
    }
  };

  // ---------- vencimento e renovação (Pix) ----------
  function checkDue() {
    if (warned || !sess || sess.dueDays == null) return;
    if (sess.dueDays <= 1) { warned = true; renewPrompt(sess.dueDays <= 0 ? 'Seu acesso vence hoje!' : 'Seu acesso vence amanhã!'); }
  }
  function renewPrompt(msg) {
    var items = canPay ? ['Renovar agora', 'Fechar'] : ['Fechar'];
    var v = {
      idx: 0,
      show: function () {
        shell('', 'Use as setas e OK');
        document.getElementById('body').innerHTML = '<div class="msg">' + esc(msg) + '\n' + (canPay ? 'Renove agora e pague pelo QR Code (Pix) aqui na TV.' : 'Fale com o seu fornecedor para renovar.') + '</div><div id="lh"></div>';
        this.draw();
      },
      draw: function () {
        var h = '<div style="position:absolute;left:700px;top:470px;width:520px">';
        for (var i = 0; i < items.length; i++) h += '<div class="row' + (i === this.idx ? ' sel' : '') + '">' + items[i] + '</div>';
        document.getElementById('lh').innerHTML = h + '</div>';
      },
      key: function (c) {
        if (c === 38 && this.idx > 0) this.idx--;
        else if (c === 40 && this.idx < items.length - 1) this.idx++;
        else if (c === 13) { if (items[this.idx] === 'Fechar') closeRenew(); else loadPlans(); return true; }
        else return false;
        this.draw(); return true;
      },
      back: function () { closeRenew(); }
    };
    view = v; v.show();
  }
  function closeRenew() {
    pollOff();
    if (expiredLogin || !sess) { expiredLogin = false; stack = []; view = null; replace(loginView); } else { view = menuView; stack = []; menuView.show(); }
  }
  var plans = [];
  function loadPlans() {
    status('Buscando planos...');
    post('/api/public/roku/renew', { owner: S.owner, usuario: S.user, senha: S.pass, action: 'plans' }, function (st, j) {
      if (st !== 200 || !j || !j.plans) { status((j && j.error) || 'Não foi possível buscar os planos.'); return; }
      plans = j.plans;
      if (plans.length === 1) { pickPlan(plans[0]); return; }
      var items = []; for (var i = 0; i < plans.length; i++) items.push({ label: plans[i].label + '  -  R$ ' + (plans[i].priceCents / 100).toFixed(2).replace('.', ',') });
      var v = { show: function () { shell('Escolha o plano', 'OK gera o Pix  |  Voltar: fechar'); this.L = makeList({ items: items, rows: 6, onSelect: function (i) { pickPlan(plans[i]); } }); this.L.render(); }, key: function (c) { return this.L.key(c); }, back: closeRenew };
      view = v; v.show();
    });
  }
  var payId = null, pollT = null;
  function pollOff() { if (pollT) { clearInterval(pollT); pollT = null; } payId = null; }
  function pickPlan(p) {
    status('Gerando o Pix...');
    post('/api/public/roku/renew', { owner: S.owner, usuario: S.user, senha: S.pass, action: 'pix', months: p.months }, function (st, j) {
      if (st !== 200 || !j || !j.paymentId) { status((j && j.error) || 'Não foi possível gerar o Pix agora.'); return; }
      payId = String(j.paymentId);
      var v = { show: function () {
        shell('Pague ' + p.label + ' - R$ ' + (p.priceCents / 100).toFixed(2).replace('.', ','), 'Abra o app do banco, escolha Pix > Ler QR Code e aponte para a TV  |  Voltar: fechar');
        document.getElementById('body').innerHTML = '<img class="qr" src="data:image/png;base64,' + j.qrCodeBase64 + '" style="width:420px;height:420px;left:750px;top:170px">';
        status('Aguardando o pagamento...');
      }, key: function () { return false; }, back: closeRenew };
      view = v; v.show();
      var n = 0; pollT = setInterval(function () {
        if (!payId) return; n++; if (n > 360) { pollOff(); status('O QR Code expirou. Feche e gere um novo.'); return; }
        xhr('GET', P + '/api/public/payment-status/' + payId, null, function (s2, t2) {
          var r = jparse(t2); if (!r || !r.status) return;
          if (r.status === 'approved') { pollOff(); shell('', ''); document.getElementById('body').innerHTML = '<div class="msg" style="top:380px">Pagamento aprovado!\nRenovando seu acesso...</div>'; expiredLogin = false; warned = true; doLogin(); }
          else if (r.status === 'rejected' || r.status === 'cancelled' || r.status === 'expired') { pollOff(); status('Pagamento não concluído. Feche e tente de novo.'); }
        });
      }, 5000);
    });
  }

  // ---------- player (AVPlay) ----------
  var pl = { cands: [], ci: 0, title: '', live: false, sid: '', series: false, paused: false, dur: 0, pos: 0, skipDone: false, act: '', ovT: null, active: false };
  function ovEl() { return document.getElementById('ov'); }
  function play(cands, title, live, sid, series) {
    pl.cands = cands; pl.ci = 0; pl.title = title; pl.live = live; pl.sid = sid; pl.series = !!series; pl.paused = false; pl.skipDone = false; pl.act = ''; pl.pos = 0; pl.dur = 0; pl.active = true;
    document.body.className = 'playing';
    app.style.display = 'block';
    app.innerHTML = '<div class="act" id="act"></div><div class="ov" id="ov"><div class="t" id="ovt"></div><div class="epg" id="epg1"></div><div class="epg2" id="epg2"></div><div class="tm" id="tm"></div><div class="bar" id="bar"><i id="barf"></i></div><div class="hint">Esquerda/Direita: voltar/avançar   Retroceder/Avançar: salto maior   OK: pausar   Voltar: sair</div></div><div class="status" id="status"></div>';
    view = playView; startCand(); showOv();
    if (live) loadEpg(sid);
  }
  function startCand() {
    var c = pl.cands[pl.ci];
    try { webapis.avplay.close(); } catch (e) {}
    try {
      webapis.avplay.open(c.url);
      webapis.avplay.setDisplayRect(0, 0, 1920, 1080);
      webapis.avplay.setListener({
        oncurrentplaytime: function (ms) { pl.pos = ms; onTime(); },
        onstreamcompleted: onEnd,
        onerror: onAvErr
      });
      webapis.avplay.prepareAsync(function () {
        try { pl.dur = webapis.avplay.getDuration(); } catch (e) {}
        webapis.avplay.play();
        var cd = pl.cands[pl.ci];
        if (pl.live && (cd.fmt === 'hls' || cd.fmt === 'ts') && S.learned !== cd.fmt) { S.learned = cd.fmt; lsSet('learned', cd.fmt); }
      }, onAvErr);
    } catch (e) { onAvErr(e); }
  }
  function onAvErr() {
    if (!pl.active) return;
    if (pl.ci + 1 < pl.cands.length) { pl.ci++; startCand(); return; }
    stopPlay('Não foi possível reproduzir. Tente outro conteúdo ou mude o Formato do fluxo.');
  }
  function stopPlay(msg) {
    pl.active = false; if (pl.ovT) clearTimeout(pl.ovT);
    try { webapis.avplay.stop(); } catch (e) {} try { webapis.avplay.close(); } catch (e2) {}
    document.body.className = '';
    view = stack.length ? stack.pop() : menuView; view.show(); if (msg) status(msg);
  }
  function onEnd() {
    if (S.autoNext && pl.series && epIdx + 1 < episodes.length) { playEp(epIdx + 1); return; }
    stopPlay('');
  }
  function fmtT(ms) { var s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return (h ? h + ':' + (m < 10 ? '0' : '') : '') + m + ':' + (x < 10 ? '0' : '') + x; }
  function showOv() {
    var o = ovEl(); if (!o) return; o.style.display = 'block';
    document.getElementById('ovt').textContent = pl.title;
    if (pl.live) { document.getElementById('bar').style.display = 'none'; document.getElementById('tm').style.display = 'none'; }
    if (pl.ovT) clearTimeout(pl.ovT);
    if (!pl.paused) pl.ovT = setTimeout(function () { var q = ovEl(); if (q) q.style.display = 'none'; }, 4000);
    onTime();
  }
  function onTime() {
    if (pl.live || !pl.active) return;
    var pos = pl.pos, dur = pl.dur;
    var f = document.getElementById('barf'); if (f && dur) f.style.width = Math.min(100, pos / dur * 100) + '%';
    var tm = document.getElementById('tm'); if (tm) tm.textContent = fmtT(pos) + ' / ' + fmtT(dur);
    var act = '', txt = '';
    if (pl.series && dur > 60000) {
      var rem = (dur - pos) / 1000;
      if (epIdx + 1 < episodes.length && rem <= CFG.nextSecs && rem > 0) { act = 'next'; txt = S.autoNext ? 'Próximo em ' + Math.ceil(rem) + '  (OK)' : 'Próximo  (OK)'; }
      else if (!pl.skipDone && dur > 300000 && pos / 1000 >= CFG.introFrom && pos / 1000 <= CFG.introTo) { act = 'intro'; txt = 'Pular abertura  (OK)'; }
    }
    pl.act = act; var a = document.getElementById('act'); if (a) { a.style.display = act ? 'block' : 'none'; a.textContent = txt; }
  }
  function seekBy(sec) {
    if (pl.live) return;
    var t = Math.max(0, Math.min(pl.dur - 2000, pl.pos + sec * 1000));
    try { webapis.avplay.seekTo(t, function () {}, function () {}); } catch (e) {}
    pl.pos = t; showOv();
  }
  function loadEpg(sid) {
    var e1 = document.getElementById('epg1'); if (e1) e1.textContent = 'Carregando programação...';
    api('get_short_epg', '&stream_id=' + enc(sid) + '&limit=3', function (j) {
      var a = document.getElementById('epg1'), b = document.getElementById('epg2'); if (!a) return;
      if (!j || !j.epg_listings || !j.epg_listings.length) { a.textContent = 'Programação indisponível para este canal'; return; }
      function d(v) { try { return decodeURIComponent(escape(atob(v || ''))); } catch (e) { try { return atob(v || ''); } catch (e2) { return ''; } } }
      function hm(ts) { var x = new Date(Number(ts) * 1000); return x.getHours() + ':' + (x.getMinutes() < 10 ? '0' : '') + x.getMinutes(); }
      var l = j.epg_listings;
      a.textContent = 'NO AR ' + hm(l[0].start_timestamp) + '-' + hm(l[0].stop_timestamp) + '  ' + d(l[0].title);
      b.textContent = l.length > 1 ? 'A SEGUIR ' + hm(l[1].start_timestamp) + '  ' + d(l[1].title) : '';
    });
  }
  var playView = {
    key: function (c) {
      if (c === 37) seekBy(-CFG.seek); else if (c === 39) seekBy(CFG.seek);
      else if (c === 412) seekBy(-CFG.seekBig); else if (c === 417) seekBy(CFG.seekBig);
      else if (c === 13 || c === 415 || c === 10252 || c === 19) {
        if (c === 13 && pl.live) { showOv(); return true; }
        if (c === 13 && pl.act === 'next') { playEp(epIdx + 1); return true; }
        if (c === 13 && pl.act === 'intro') { pl.skipDone = true; seekBy(Math.max(CFG.introEnd, pl.pos / 1000 + 10) - pl.pos / 1000); return true; }
        if (pl.live) return true;
        try { if (pl.paused) { webapis.avplay.play(); pl.paused = false; } else { webapis.avplay.pause(); pl.paused = true; } } catch (e) {}
        showOv(); if (pl.paused && pl.ovT) clearTimeout(pl.ovT);
      } else if (c === 38 || c === 40) showOv(); else return false;
      return true;
    },
    back: function () { stopPlay(''); }
  };

  // ---------- teclas ----------
  document.addEventListener('keydown', function (e) {
    if (!view) return;
    var c = e.keyCode;
    if (c === 10009 || c === 27 || (c === 8 && !(document.activeElement && document.activeElement.tagName === 'INPUT'))) {
      e.preventDefault();
      if (view.back) view.back(); else back();
      return;
    }
    if (view.key && view.key(c, e)) e.preventDefault();
  });

  function start(panel, owner) {
    P = panel; OWNER = owner || '';
    S.owner = ls('owner') || OWNER; S.user = ls('user'); S.pass = ls('pass');
    S.fmt = ls('fmt') || 'auto'; if (S.fmt !== 'ts' && S.fmt !== 'hls') S.fmt = 'auto';
    S.learned = ls('learned'); S.autoNext = ls('autonext') !== '0'; S.font = parseInt(ls('font') || '0', 10) || 0; setFont();
    xhr('GET', P + '/api/public/roku/config', null, function (st, txt) {
      var j = st === 200 ? jparse(txt) : null;
      if (j) { for (var k in CFG) if (j[k] !== undefined) CFG[k] = j[k]; }
      if (CFG.maintenance) { shell('Em manutenção', 'Pressione Voltar para sair'); status(CFG.maintenanceMsg); view = { root: true, show: function () {}, key: function () { return false; } }; return; }
      loadTheme(function () { if (S.user && S.pass) doLogin(); else replace(loginView); });
    }, 10000);
  }
  return { start: start };
})();
